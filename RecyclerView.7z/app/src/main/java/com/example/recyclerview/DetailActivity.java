package com.example.recyclerview;

import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class DetailActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail);

        // Получение данных из Intent
        String name = getIntent().getStringExtra("name");
        String capital = getIntent().getStringExtra("capital");
        int flagResId = getIntent().getIntExtra("flag", 0);

        // Найти элементы в макете и установить данные
        TextView nameView = findViewById(R.id.nameDetail);
        TextView capitalView = findViewById(R.id.capitalDetail);
        ImageView flagView = findViewById(R.id.flagDetail);

        nameView.setText(name);
        capitalView.setText(capital);
        flagView.setImageResource(flagResId);
    }
}

