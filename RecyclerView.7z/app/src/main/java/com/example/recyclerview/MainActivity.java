package com.example.recyclerview;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    ArrayList<State> states = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Инициализация данных
        setInitialData();

        // Настройка RecyclerView
        RecyclerView recyclerView = findViewById(R.id.recycler_view);
        StateAdapter adapter = new StateAdapter(this, states);
        recyclerView.setAdapter(adapter);
    }

    private void setInitialData() {
        // Добавление данных в список
        states.add(new State("Нью-Йорк", "Спасаем город", R.drawable.anim3));
        states.add(new State("Город ночи", "Человек-паук", R.drawable.anim2));
        states.add(new State("Нью-Йорк", "Очень круто", R.drawable.anim1));
    }
}
