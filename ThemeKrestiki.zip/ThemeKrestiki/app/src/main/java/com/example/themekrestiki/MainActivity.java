package com.example.themekrestiki;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Установка фона в зависимости от текущей темы
        setBackground();

        Button playWithFriendButton = findViewById(R.id.play_with_friend);
        playWithFriendButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, GameActivity.class);
                intent.putExtra("game_mode", "vs_friend");
                startActivity(intent);
            }
        });

        Button playWithBotButton = findViewById(R.id.play_with_bot);
        playWithBotButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, GameActivity.class);
                intent.putExtra("game_mode", "vs_bot");
                startActivity(intent);
            }
        });

        Button themeButton = findViewById(R.id.theme_button);
        themeButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ThemeManager.toggleTheme(MainActivity.this);
                setBackground(); // Установить новый фон после переключения темы
            }
        });

        Button statisticsButton = findViewById(R.id.statistics_button);
        statisticsButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, StatisticsActivity.class);
                startActivity(intent);
            }
        });
    }

    private void setBackground() {
        String theme = ThemeManager.getCurrentTheme(this);
        if (theme.equals("dark")) {
            findViewById(R.id.main_layout).setBackgroundResource(R.drawable.temno);
        } else {
            findViewById(R.id.main_layout).setBackgroundResource(R.drawable.svetlo);
        }
    }
}
