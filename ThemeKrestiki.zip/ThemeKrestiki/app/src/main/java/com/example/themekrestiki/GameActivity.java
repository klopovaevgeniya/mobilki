package com.example.themekrestiki;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.GridLayout;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class GameActivity extends AppCompatActivity {

    private Button[][] buttons = new Button[3][3];
    private boolean player1Turn = true; // True for X, False for O
    private String gameMode;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_game);

        // Установка фона в зависимости от текущей темы
        setBackground();

        gameMode = getIntent().getStringExtra("game_mode");
        GridLayout gameBoard = findViewById(R.id.game_board);

        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                int buttonID = getResources().getIdentifier("button_" + (i * 3 + j),
                        "id", getPackageName());
                buttons[i][j] = findViewById(buttonID);
                buttons[i][j].setOnClickListener(new ButtonClickListener(i, j));
            }
        }
    }

    private class ButtonClickListener implements View.OnClickListener {
        private int row;
        private int col;

        ButtonClickListener(int row, int col) {
            this.row = row;
            this.col = col;
        }

        @Override
        public void onClick(View v) {
            if (!buttons[row][col].getText().toString().equals("")) {
                return; // Если кнопка уже нажата, ничего не делать
            }

            if (player1Turn) {
                buttons[row][col].setText("X");
            } else {
                buttons[row][col].setText("O");
            }

            if (checkWin()) {
                String winner = player1Turn ? "X" : "O";
                updateStatistics(player1Turn ? "win" : "loss");
                Toast.makeText(GameActivity.this, "Победил " + winner, Toast.LENGTH_SHORT).show();
                resetGame();
            } else if (isDraw()) {
                updateStatistics("draw");
                Toast.makeText(GameActivity.this, "Ничья!", Toast.LENGTH_SHORT).show();
                resetGame();
            } else {
                player1Turn = !player1Turn;
                if (gameMode.equals("vs_bot") && !player1Turn) {
                    botMove(); // Ход бота, если его очередь
                }
            }
        }
    }

    private boolean checkWin() {
        // Проверка победы по строкам и столбцам
        for (int i = 0; i < 3; i++) {
            if (buttons[i][0].getText().toString().equals(buttons[i][1].getText().toString()) &&
                    buttons[i][1].getText().toString().equals(buttons[i][2].getText().toString()) &&
                    !buttons[i][0].getText().toString().equals("")) {
                return true; // Проверка строк
            }
            if (buttons[0][i].getText().toString().equals(buttons[1][i].getText().toString()) &&
                    buttons[1][i].getText().toString().equals(buttons[2][i].getText().toString()) &&
                    !buttons[0][i].getText().toString().equals("")) {
                return true; // Проверка столбцов
            }
        }
        return (buttons[0][0].getText().toString().equals(buttons[1][1].getText().toString()) &&
                buttons[1][1].getText().toString().equals(buttons[2][2].getText().toString()) &&
                !buttons[0][0].getText().toString().equals("")) || // Проверка диагонали
                (buttons[0][2].getText().toString().equals(buttons[1][1].getText().toString()) &&
                        buttons[1][1].getText().toString().equals(buttons[2][0].getText().toString()) &&
                        !buttons[0][2].getText().toString().equals("")); // Проверка анти-диагонали
    }

    private boolean isDraw() {
        // Проверка на ничью
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                if (buttons[i][j].getText().toString().equals("")) {
                    return false; // Если есть пустые ячейки, то нет ничьей
                }
            }
        }
        return true; // Все ячейки заполнены
    }

    private void resetGame() {
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                buttons[i][j].setText("");
            }
        }
        player1Turn = true; // Сбросить ход игрока
    }

    private void botMove() {
        // Логика бота: находит первую пустую ячейку и делает ход
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                if (buttons[i][j].getText().toString().equals("")) {
                    buttons[i][j].setText("O");
                    if (checkWin()) {
                        Toast.makeText(GameActivity.this, "Победил бот", Toast.LENGTH_SHORT).show();
                        updateStatistics("loss");
                        resetGame();
                    }
                    player1Turn = true; // Сбросить ход игрока
                    return;
                }
            }
        }
    }

    private void updateStatistics(String result) {
        SharedPreferences sharedPreferences = getSharedPreferences("GamePrefs", MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();

        int wins = sharedPreferences.getInt("wins", 0);
        int losses = sharedPreferences.getInt("losses", 0);
        int draws = sharedPreferences.getInt("draws", 0);

        switch (result) {
            case "win":
                wins++;
                editor.putInt("wins", wins);
                break;
            case "loss":
                losses++;
                editor.putInt("losses", losses);
                break;
            case "draw":
                draws++;
                editor.putInt("draws", draws);
                break;
        }
        editor.apply(); // Сохранение изменений в SharedPreferences
    }

    private void setBackground() {
        String theme = ThemeManager.getCurrentTheme(this);
        if (theme.equals("dark")) {
            findViewById(R.id.game_layout).setBackgroundResource(R.drawable.temno);
        } else {
            findViewById(R.id.game_layout).setBackgroundResource(R.drawable.svetlo);
        }
    }
}
