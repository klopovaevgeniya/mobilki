package com.example.themekrestiki;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class StatisticsActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_statistics);

        // Установка фона в зависимости от текущей темы
        setBackground();

        TextView statsTextView = findViewById(R.id.stats_text_view);
        SharedPreferences sharedPreferences = getSharedPreferences("GamePrefs", MODE_PRIVATE);

        int wins = sharedPreferences.getInt("wins", 0);
        int losses = sharedPreferences.getInt("losses", 0);
        int draws = sharedPreferences.getInt("draws", 0);

        String stats = "Победы: " + wins + "\nПроигрыши: " + losses + "\nНичьи: " + draws;
        statsTextView.setText(stats);
    }

    private void setBackground() {
        String theme = ThemeManager.getCurrentTheme(this);
        if (theme.equals("dark")) {
            findViewById(R.id.statistics_layout).setBackgroundResource(R.drawable.temno);
        } else {
            findViewById(R.id.statistics_layout).setBackgroundResource(R.drawable.svetlo);
        }
    }
}

