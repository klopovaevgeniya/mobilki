package com.example.themekrestiki;

import android.content.Context;
import android.content.SharedPreferences;

public class ThemeManager {

    private static final String PREF_NAME = "ThemePrefs";
    private static final String KEY_THEME = "current_theme";

    public static String getCurrentTheme(Context context) {
        SharedPreferences preferences = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
        return preferences.getString(KEY_THEME, "light");
    }

    public static void toggleTheme(Context context) {
        SharedPreferences preferences = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = preferences.edit();
        String currentTheme = getCurrentTheme(context);

        // Переключение темы
        if (currentTheme.equals("light")) {
            editor.putString(KEY_THEME, "dark");
        } else {
            editor.putString(KEY_THEME, "light");
        }
        editor.apply(); // Сохранить изменения
    }
}

